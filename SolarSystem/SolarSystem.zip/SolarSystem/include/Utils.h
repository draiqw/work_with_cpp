#pragma once
#include <string>
#include <ctime>

double date_to_seconds(const std::string& target, const std::string& epoch);
