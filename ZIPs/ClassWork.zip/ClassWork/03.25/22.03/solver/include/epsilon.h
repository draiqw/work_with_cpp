template <typename T> T epsilon1();
template <typename T> T epsilon0();