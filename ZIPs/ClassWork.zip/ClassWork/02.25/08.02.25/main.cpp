#include <iostream>  
#include <quadmath.h>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;  
}
