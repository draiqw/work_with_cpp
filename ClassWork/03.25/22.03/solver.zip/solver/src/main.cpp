#include <iostream>
#include <vector>
#include <stdexcept>
#include <algorithm>
#include <epsilon.h>
#include <matrix.h>

int main(){
    std::cout << "Hello, World!" << std::endl;

    std::cout << "epsilon1 <float> = " << epsilon1 <float>() << std::endl;
    std::cout << "epsilon1 <double> = " << epsilon1 <double>() << std::endl;
    std::cout << "epsilon1 <long double> = " << epsilon1 <long double>() << std::endl;

    std::cout << "epsilon0 <float> = " << epsilon0 <float>() << std::endl;
    std::cout << "epsilon0 <double> = " << epsilon0 <double>() << std::endl;
    std::cout << "epsilon0 <long double> = " << epsilon0 <long double>() << std::endl;

    Matrix <double> m(3, 3);
    m(0, 0) = 1;
    m(0, 1) = 2;
    m(0, 2) = 3;
    m(1, 0) = 4;
    m(1, 1) = 5;
    m(1, 2) = 6;
    m(2, 0) = 7;
    m(2, 1) = 8;
    m(2, 2) = 9;

    std::cout<<m << std::endl;  // m.print();
    
    return 0;


}